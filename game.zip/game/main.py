#uses pygame
#background image from https://background4free.com/download/blue-yellow-light-free-background-image-2
import pygame
import random
import crate

score=0

bg=pygame.transform.scale(pygame.image.load("wow.jpg"),[650,500])

if __name__ == "__main__":
    pygame.init()
    size=(650,500)
    screen=pygame.display.set_mode(size)
    pygame.display.set_caption("Random Game?")
    vt323=pygame.font.Font('vt323.ttf',34)
    smallvt323=pygame.font.Font('vt323.ttf',15)
    title=pygame.font.Font('burnstown dam.ttf',80)

    
commonimg=pygame.transform.scale(crate.commonimg,[25,25])
rareimg=pygame.transform.scale(crate.rareimg,[25,25])
richimg=pygame.transform.scale(crate.richimg,[25,25])
epicimg=pygame.transform.scale(crate.epicimg,[25,25])
legendaryimg=pygame.transform.scale(crate.legendaryimg,[25,25])
    
availablecrates=[crate.common]
queuedcrates=[[crate.rare,rareimg,35,"Rare"],[crate.rich,richimg,80,"Rich"],[crate.epic,epicimg,120,"Epic"],[crate.legendary,legendaryimg,140,"Legendary"]]
currentcrate=0


"""def newcrate():
    currentcrate=crate.crate(random.choice(availablecrates))"""

def unlock():
    global score
    if True in pygame.mouse.get_pressed():
        mouse=pygame.mouse.get_pos()
        if mouse[0]>=500 and mouse[0]<=500+25:
            if mouse[1]>=120 and mouse[1]<=120+25:
                if score>=queuedcrates[0][2]:
                    score-=queuedcrates[0][2]
                    availablecrates.append(queuedcrates.pop(0)[0])
                else:
                    pass
            else:
                pass       
        else:
            pass
    else:
        waitingformouseup=False

closed=False#Symmetry get it hermitcraft refernces ahahahaha.

#newcrate()
currentcrate=crate.crate(random.choice(availablecrates))

while not closed:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
       
            
    if currentcrate.isclicked()[1]:
        score+=currentcrate.drop()
        currentcrate=crate.crate(random.choice(availablecrates))
        
    unlock()
    
    screen.fill((0,0,0))
    screen.blit(bg,(0,0))
    currentcrate.draw(screen)
    #scoreText = vt323.render("SCORE:" + str(score), 1, (255,255,255))
    scoretext = vt323.render(str(score),1,(0,0,0))
    #screen.blit(scoreText, (350, 50))
    screen.blit(scoretext,(50,120))
    
    if score>=queuedcrates[0][2]:
        buycolor=(0,200,0)
    else:
        buycolor=(255,50,50)
    buytext=smallvt323.render("Unlock "+queuedcrates[0][3]+":"+str(queuedcrates[0][2]),1,buycolor)
    screen.blit(buytext,(480,165))
    screen.blit(queuedcrates[0][1],(500,120))
    
    titletext=title.render("Crate clicker",1,(0,0,0))
    subtitle=smallvt323.render("By Kyle Zhou \"This looks like an online game with bad css\"",1,(0,0,0))
    programmer=smallvt323.render("Written by Kyle Zhou",1,(0,0,0))
    bgc=smallvt323.render("Background Image from https://",1,(0,0,0))
    bgc2=smallvt323.render("background4free.com/download/",1,(0,0,0))
    bgc3=smallvt323.render("blue-yellow-light-f",1,(0,0,0))
    bgc4=smallvt323.render("free-background-image-2",1,(0,0,0))
    screen.blit(subtitle,(120,80))
    screen.blit(titletext,(120,0))
    screen.blit(programmer,(420,300))
    screen.blit(bgc,(420,320))
    screen.blit(bgc2,(420,340))
    screen.blit(bgc3,(420,360))
    screen.blit(bgc4,(420,380))
    
    
    pygame.display.flip()
    

        
        
pygame.quit()
