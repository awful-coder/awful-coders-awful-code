#uses pygame
import pygame
import random
#import time
from math import floor
#import waiting
gold=pygame.image.load("gold.png")
diamond=pygame.image.load("diamond.png")
poof=pygame.image.load("poof.png")

commonimg=pygame.image.load("common.png")
rareimg=pygame.image.load("rare.png")
richimg=pygame.image.load("rich.png")
epicimg=pygame.image.load("epic.png")
legendaryimg=pygame.image.load("legendary.png")

common=[[1,1,1,2,2,3,0,0],commonimg]
rare=[[2,2,2,3,3,4,5,0],rareimg]
rich=[[3,3,4,4,4,5,5,0],richimg]
epic=[[3,4,4,5,5,6],epicimg]
legendary=[[4,4,4,5,5,6,6,7,7],legendaryimg]

"""def notclicked():
    if True in pygame.mouse.get_pressed():
        return False
    return True"""

waitingformouseup=False

class crate:
    def __init__(self,cratetype):
        self.loot=cratetype[0]
        self.image=cratetype[1]
        self.display=0
        self.size=1
        self.length=100
        self.clicked=0
        self.x=140
        self.y=250
        
        self.drops=random.choice(self.loot)
        self.showloot=False
        self.lootpositions=[]
        for x in range(floor(self.drops/5)):
            self.lootpositions.append([random.randint(-40,40)+40,random.randint(-40,40)+40])
        for x in range(self.drops-floor(self.drops/5)):
            self.lootpositions.append([random.randint(-40,40)+40,random.randint(-40,40)+40])
        #print (self.lootpositions)

    def drop(self):
        return (self.drops)

    def draw(self,screen):
        if self.showloot:
            if self.drops>0:
                i=0
                for x in range(floor(self.drops/5)):
                    screen.blit(diamond,[self.x+self.lootpositions[x][0],self.y+self.lootpositions[x][1]])
                    i+=1
                
                for x in range(self.drops-floor(self.drops/5)):
                    #screen.blit(gold,[self.x+random.randint(-40,40),self.y+random.randint(-40,40)])
                    screen.blit(gold,[self.x+self.lootpositions[x+i][0],self.y+self.lootpositions[x+i][1]])
            else:
                screen.blit(poof,[self.x,self.y])
        else:
            self.display=pygame.transform.scale(self.image,(int(self.length*self.size),int(self.length*self.size)))
            screen.blit(self.display,[self.x,self.y])

    def isclicked(self):
        global waitingformouseup
        if True in pygame.mouse.get_pressed():
            mouse=pygame.mouse.get_pos()
            if not waitingformouseup:
                waitingformouseup=True
                if mouse[0]>=self.x and mouse[0]<=self.x+(self.length*self.size):
                    if mouse[1]>=self.y and mouse[1]<=self.y+(self.length*self.size):
                        self.clicked+=1
                        self.size+=0.2
                        #self.x-=int(((self.length*self.size)-(self.length*(self.size-1)/2)))
                        self.x-=((self.length*1.2)-self.length)/2
                        self.y-=((self.length*1.2)-self.length)/2
                    
                        #waiting.wait(lambda: notclicked) is True
                    
                        if self.clicked>5:
                            return [True,True]
                        else:
                            if self.clicked>4:
                                self.showloot=True
                            return [True,False]
                    else:
                        return [False,False]
                else:
                    return [False,False]
            else:
                return [False,False]
        else:
            waitingformouseup=False
            return [False,False]
        
